import json
import ipfshttpclient
from flask import Flask, request, jsonify, render_template
from web3 import Web3

w3 = Web3(Web3.HTTPProvider("https://mainnet.infura.io/v3/5945bbd3af2c49708510f1ab0d8e4b11"))

contract_address = '0xYourValidContractAddressHere'
contract_abi = [
    
]

contract = w3.eth.contract(address=contract_address, abi=contract_abi)

ipfs_client = ipfshttpclient.connect("/ip4/127.0.0.1/tcp/5001/http")

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register_student', methods=['POST'])
def register_student():
    data = request.form
    student_address = data["student_address"]
    name = data["name"]

    try:
        tx_hash = contract.functions.registerStudent(student_address, name).transact({"from": w3.eth.accounts[0]})
        w3.eth.wait_for_transaction_receipt(tx_hash)
        return jsonify({"message": "Student registered successfully!"}), 200
    except Exception as e:
        return jsonify({"message": str(e)}), 500

@app.route('/upload_resume', methods=['POST'])
def upload_resume():
    student_address = request.form['student_address']
    file = request.files['resume']
    
    try:
        # Upload the file to IPFS
        res = ipfs_client.add(file)
        ipfs_hash = res["Hash"]
        
        # Call the smart contract to save the IPFS hash
        tx_hash = contract.functions.uploadResume(ipfs_hash).transact({"from": student_address})
        w3.eth.wait_for_transaction_receipt(tx_hash)

        return jsonify({"message": "Resume uploaded successfully!", "ipfs_hash": ipfs_hash}), 200
    except Exception as e:
        return jsonify({"message": str(e)}), 500

if __name__ == "__main__":
    app.run(port=5000)
