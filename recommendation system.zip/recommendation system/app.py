from flask import Flask, render_template
import re
import nltk
from nltk.tokenize import word_tokenize
import google.generativeai as genai

# Download necessary NLTK data
nltk.download('punkt')

# Configure Gemini AI
genai.configure(api_key="AIzaSyA-0rkCfbueku01YoBpVlktuxKZmqd7Z2U")
model = genai.GenerativeModel("gemini-pro")

app = Flask(__name__)

def extract_information(resume_text):
    """Extracts certifications, internships, and experience from structured resume text."""
    sections = {"Certifications": [], "Internships": [], "Experience": []}
    current_section = None

    lines = resume_text.split("\n")
    for line in lines:
        line = line.strip()
        if re.match(r'(?i)^(Certifications|Internships|Experience)\s*:?$', line):
            current_section = line.rstrip(':').capitalize()
        elif current_section and line:
            sections[current_section].append(line)

    certifications = sections["Certifications"]
    return certifications

def calculate_ats_score(resume_text, job_title):
    """Calculates ATS score based on extracted resume details."""
    high_value_platforms = {"Google", "Coursera", "Udemy", "Harvard", "MIT", "Stanford"}

    certifications = extract_information(resume_text)
    score = 20  # Base score

    for cert in certifications:
        platform = cert.split("-")[0].strip() if "-" in cert else "Unknown Platform"
        if platform in high_value_platforms:
            score += 10
        else:
            score += 5

    return score

def get_recommendations(resume_text, job_title):
    """Uses Gemini AI to generate recommendations for ATS improvement and certifications."""
    ats_score = calculate_ats_score(resume_text, job_title)

    prompt = f"""
    Based on the resume contents and job title '{job_title}', provide:
    1. Ways to improve the ATS score. Current ATS score: '{ats_score}'.
    2. High-value certification courses to take and their links.
    """
    
    response = model.generate_content(prompt)
    return response.text

def get_youtube_recommendations():
    """Returns hardcoded YouTube recommendations."""
    return [
        {"title": "What is Data Analytics?", "video_id": "PSNXoAs2FtQ", "description": "The Data Analyst Boot Camp is designed for beginners, covering core topics like SQL, Tableau, Power BI, Python, and Excel to help develop essential data analysis skills. Resources for learning include Alex the Analyst's free YouTube tutorials, Udemy for affordable courses, Coursera for professional content, and platforms like DataCamp and DataQuest for text-based and gamified learning experiences. Building a strong portfolio through projects is crucial for showcasing skills to potential employers. A well-crafted resume highlighting relevant skills, projects, and quantifiable achievements is key for job applications. Networking, working with recruiters, and applying through platforms like LinkedIn can help secure interviews. The learning process typically takes 3 to 4 months, with an additional 3 to 6 weeks for portfolio development, leading to a total of about 6 months to land a data analyst position. Data visualization using tools like Tableau and Power BI is emphasized as a critical skill for presenting data insights."},
        {"title": "Data Science for Beginners", "video_id": "ETQ97mXXF0", "description": "Edureka offers a comprehensive master's program in data science, including 12 courses and over 250 hours of interactive learning, starting with Python programming. The program covers nine modules, designed for beginners and aspiring data scientists. Data Science, as a revolutionary technology, focuses on deriving insights from data to solve real-world problems. Resources like DataCamp allow learners to progress at their own pace, offering courses ranging from non-coding basics to advanced data science and machine learning. The Data Science Fundamentals course includes essential skills like exploratory data analysis (EDA) and using Excel for analytics. Graduates are expected to apply data visualization and pre-processing techniques and use both commercial and open-source tools. The Python for Data Science Bootcamp teaches key programming libraries like NumPy, Pandas, Matplotlib, and Seaborn. It also covers machine learning algorithms such as K-Means clustering, logistic regression, random forests, and neural networks, equipping students with valuable skills for data science careers"},
        {"title": "Python for Data Analysis", "video_id": "r-uOLxNrNk8", "description": """Data Analysis with Python: Zero to Pandas" is a beginner-friendly live online course that introduces coding and data analysis, offering a verified certificate upon completion. The course covers essential data analysis and visualization tools, such as Matplotlib and Seaborn, commonly used in scientific research. The Comprehensive Python for Data Science Bootcamp includes key libraries like NumPy for numerical data, Pandas for analysis, and Matplotlib for plotting. It also covers Seaborn for statistical plots, Plotly for interactive visualizations, and SciKit-Learn for machine learning tasks, including algorithms like K-Means Clustering, Logistic Regression, Random Forest, and Neural Networks. Additional learning resources include books like "Data Science for Business" by Foster Provost, "Python for Data Analysis" by Wes McKinney, and "Storytelling with Data" by Cole Nussbaumer Knaflic. This course is ideal for both beginners and traditional data analysts seeking to enhance their Python and data analysis skills."""},
        {"title": "Machine Learning Crash Course", "video_id": "GwIo3gDZCVQ", "description": "Edureka offers a Machine Learning Engineer Master's Program with over 200 hours of interactive training across nine modules, beginning with Python programming. The curriculum prepares learners for the growing global demand for machine learning engineers, covering machine learning algorithms, project implementation, and practical applications. Additional learning resources include online courses from Stanford University (via Coursera) and specialized courses like Mathematics for Machine Learning. The program emphasizes hands-on projects such as fake news detection and object detection, which help build a professional portfolio. Students will also gain technical skills using tools like TensorFlow, Keras, and Apache Spark, and learn data visualization, reinforcement learning, clustering algorithms, and model validation techniques. The course also covers essential interview questions for aspiring machine learning engineers. Prospective students are encouraged to express interest by submitting their email IDs for more information and enrollment details."},
        {"title": "SQL for Data Analysts", "video_id": "7S_tz1z_5bA", "description": "Mosh Hamedani, a software engineering expert with over 20 years of experience, instructs courses in SQL, Java, and Python, aiming to make software engineering accessible. His teaching reaches millions through online platforms. Mosh offers a three-hour SQL course for beginners, helping them interact with relational database management systems, with a full MySQL course available for free on his YouTube channel. The SQL tutorial condenses key concepts from a full course, focusing on deploying full-stack applications. MySQL is a critical open-source database used by developers for database-driven web applications, with platforms like WordPress, Facebook, and YouTube relying on it. The MySQL tutorial series is structured in beginner, intermediate, and advanced levels, covering essential commands like connecting to a MySQL database and selecting specific databases. The series emphasizes practical skills to help learners gain hands-on experience in MySQL development."}
    ]

@app.route('/')
def index():
    resume_text = """
    Certifications:
    Coursera - Data Science
    Udemy - Machine Learning
    Google - Python for Data Science
    """
    job_title = "Data Analyst"

    ats_recommendations = get_recommendations(resume_text, job_title)
    youtube_videos = get_youtube_recommendations()
    
    return render_template('index.html', ats_recommendations=ats_recommendations, videos=youtube_videos)

if __name__ == '__main__':
    app.run(debug=True)
