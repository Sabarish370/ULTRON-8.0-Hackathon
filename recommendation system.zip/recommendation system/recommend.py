import re
import nltk
from nltk.tokenize import word_tokenize
import google.generativeai as genai
import datetime
nltk.download('punkt')
nltk.download('punkt_tab')


import google.generativeai as genai
model = genai.GenerativeModel("gemini-pro")
# Ensure the API key is set before making requests
genai.configure(api_key="AIzaSyA-0rkCfbueku01YoBpVlktuxKZmqd7Z2U")
# Correct way to configure API key
genai.configure(api_key="AIzaSyA-0rkCfbueku01YoBpVlktuxKZmqd7Z2U") 
                                                                                                                                                                                                                                                                                                          

def extract_information(resume_text):
    """Extracts certifications, internships, and experience from structured resume text."""
    sections = {"Certifications": [], "Internships": [], "Experience": []}
    current_section = None

    lines = resume_text.split("\n")
    for line in lines:
        line = line.strip()
        if re.match(r'(?i)^(Certifications|Internships|Experience)\s*:?$', line):
            current_section = line.rstrip(':').capitalize()
        elif current_section and line:
            sections[current_section].append(line)

    certifications = sections["Certifications"]
    internships = sections["Internships"]
    experiences = sections["Experience"]

    return certifications, internships, experiences

def calculate_ats_score(resume_text, job_title):
    """Calculates ATS score based on extracted resume details."""
    high_value_platforms = {"Google", "Coursera", "Udemy", "Harvard", "MIT", "Stanford"}
    low_value_platforms = {"Local University", "Unknown Platform", "Basic Online Course"}
    high_value_companies = {"Google", "Microsoft", "Amazon", "Facebook", "Tesla", "Apple"}
    low_value_companies = {"Small Startup", "Local Business", "Unknown Company"}

    certifications, internships, experiences = extract_information(resume_text)
    
    score = 20  # Base score
    
    # Tokenize resume and job title
    resume_tokens = set(word_tokenize(resume_text.lower()))
    job_title_tokens = set(word_tokenize(job_title.lower()))

    # Process Certifications
    for cert in certifications:
        platform = cert.split("-")[0].strip() if "-" in cert else "Unknown Platform"
        cert_name = cert.split("-")[-1].strip()
        
        if platform in high_value_platforms and cert_name in resume_tokens:
            score += 10
        elif platform in low_value_platforms and cert_name in resume_tokens:
            score += 2
        else:
            score += 5

    # Process Internships
    for intern in internships:
        company = intern.split("-")[0].strip() if "-" in intern else "Unknown Company"
        skill = intern.split("-")[-1].strip()
        
        if company in high_value_companies and skill in resume_tokens:
            score += 15
        elif company in low_value_companies and skill in resume_tokens:
            score += 5
        else:
            score += 10
    
    # Process Experience
    for exp in experiences:
        company = exp.split("-")[0].strip() if "-" in exp else "Unknown Company"
        role = exp.split("-")[-1].strip()
        
        if company in high_value_companies and role in job_title_tokens:
            score += 20
        elif company in low_value_companies and role in job_title_tokens:
            score += 10
        else:
            score += 5
    
    return score

def get_recommendations(resume_text, job_title, score):
    """Uses Google Gemini AI to recommend improvements, certifications, and internships."""
    prompt = f"""
    Based on the resume contents, the job title '{job_title}', and certifications, provide:
    1. Ways to improve the ATS score. Providing my ATS score: '{score}' for the job title '{job_title}'.
    2. High-value certification courses to take and their links to the platform.
    3. Best youtube videos that can be recommended for the job title '{job_title}'to improve the knowledge about it. 
    """
    response = model.generate_content(prompt)
    return response.text

def get_recommendation():
    # Get the current time
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Create a prompt with the current time
    prompt = f"Find the newest popular video on YouTube as of {current_time}."
    
    # Your existing logic to fetch video recommendations
    # For example, using an API or a search function
    # recommended_video = fetch_video_based_on_prompt(prompt)
    
    # return recommended_video
    return prompt  # For demonstration purposes, returning the prompt

# Example usage:
resume_text = """
Certifications:
Coursera - Data Science
Udemy - Machine Learning

Internships:
Google - Data Analyst
Small Startup - Python Developer

Experience:
Amazon - Data Scientist
Unknown Company - Research Assistant
"""
job_title = "Data Analyst"

ats_score = calculate_ats_score(resume_text, job_title)
recommendations = get_recommendations(resume_text, job_title, ats_score)

print(f"ATS Score: {ats_score}")
print("\nRecommendations:")
print(recommendations)
