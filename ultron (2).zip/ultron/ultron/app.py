import re
from flask import Flask, request, jsonify,render_template
import base64
import os
import os
import google.generativeai as genai
import PIL.Image

def trigger():
    # Set up API key
    genai.configure(api_key="AIzaSyBXf3wfL0hwjXpHVPf_FjJwWonyGyuX8RQ")


    # Path to your image
    image_path = "captured_images\\whiteboard_capture.png"  # Adjust the path as needed
    image = PIL.Image.open(image_path)

    # Create a model instance
    model = genai.GenerativeModel("gemini-1.5-flash")

    # Send the image to Gemini AI with a query to get the text solution
    response = model.generate_content([image, "Solve this problem and provide the solution as text. and describe how the solution came explain.."])

    # Check if response has text content
    if response and response.parts:
        for part in response.parts:
            if hasattr(part, "text"):
                solution_text = part.text
                print("Solution Text:", solution_text)
    
    else:
        print("No text response received.")
    with open("solution.txt", "w") as f:
        f.write(solution_text)


app = Flask(__name__)

SAVE_DIR = "captured_images"
os.makedirs(SAVE_DIR, exist_ok=True)
@app.route('/')
def capturwwwe():
    return render_template('index.html')
@app.route('/capture', methods=['POST'])
def capture():
    try:
        data = request.json.get('image')
        if not data:
            return jsonify({"error": "No image data received"}), 400
        
        # Decode Base64 image data
        image_data = data.split(",")[1]
        image_bytes = base64.b64decode(image_data)

        # Save image
        image_path = os.path.join(SAVE_DIR, "whiteboard_capture.png")
        with open(image_path, "wb") as img_file:
            img_file.write(image_bytes)
        trigger()
        return jsonify({"message": "Image saved successfully!", "path": image_path})

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route('/get_solution', methods=['GET'])
def get_solution():
    try:
        with open(r'C:\Users\Sabarish\Desktop\ultron\solution.txt', 'r') as file:
            content = file.read()
        return jsonify({'solution': content})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)