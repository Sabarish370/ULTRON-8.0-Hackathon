import os
import google.generativeai as genai
import PIL.Image

# Set up API key
genai.configure(api_key="AIzaSyBXf3wfL0hwjXpHVPf_FjJwWonyGyuX8RQ")


# Path to your image
image_path = "captured_images\\whiteboard_capture.png"  # Adjust the path as needed
image = PIL.Image.open(image_path)

# Create a model instance
model = genai.GenerativeModel("gemini-1.5-flash")

# Send the image to Gemini AI with a query to get the text solution
response = model.generate_content([image, "Solve this problem and provide the solution as text."])

# Check if response has text content
if response and response.parts:
    for part in response.parts:
        if hasattr(part, "text"):
            solution_text = part.text
            print("Solution Text:", solution_text)
else:
    print("No text response received.")
